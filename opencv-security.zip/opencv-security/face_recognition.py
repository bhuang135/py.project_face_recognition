import cv2
import os
import numpy as np

def recognize_face(authorized_dir='authorized_faces'):
    """使用 OpenCV 進行人臉辨識。"""
    authorized_faces = []
    for file_name in os.listdir(authorized_dir):
        if file_name.endswith('.jpg'):
            img_path = os.path.join(authorized_dir, file_name)
            face_img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
            if face_img is not None:
                authorized_faces.append(cv2.resize(face_img, (100, 100)))

    if not authorized_faces:
        print("授權目錄中無有效圖像，請添加圖像。")
        return False

    cam = cv2.VideoCapture(0)
    if not cam.isOpened():
        print("無法啟動攝影機。")
        return False

    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    if face_cascade.empty():
        print("無法加載人臉檢測模型。")
        return False

    print("請看向攝影機以進行臉部辨識...")
    while True:
        ret, frame = cam.read()
        if not ret:
            print("無法讀取攝影機畫面。")
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)

        for (x, y, w, h) in faces:
            face_img = cv2.resize(gray[y:y+h, x:x+w], (100, 100))
            for auth_face in authorized_faces:
                res = cv2.matchTemplate(face_img, auth_face, cv2.TM_CCOEFF_NORMED)
                similarity = np.max(res)
                if similarity > 0.6:  # 相似度閾值
                    print(f"臉部辨識成功，相似度：{similarity:.2f}")
                    cam.release()
                    cv2.destroyAllWindows()
                    return True

        cv2.imshow("Face Recognition", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):  # 按下 'q' 鍵退出
            break

    cam.release()
    cv2.destroyAllWindows()
    print("臉部辨識失敗。")
    return False


if __name__ == "__main__":
    if not recognize_face():
        # 創建臨時文件通知 AHK 脚本阻止訪問
        with open("C:\\Users\\yourlocal\\Desktop\\opencv-security\\temp_denied.lock", "w") as f:
            f.write("denied")
