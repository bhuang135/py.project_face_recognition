import cv2
import os

def capture_user_face(user_id, save_dir='authorized_faces'):
    os.makedirs(save_dir, exist_ok=True)  # 確保目錄存在
    cam = cv2.VideoCapture(0)  # 開啟攝影機
    if not cam.isOpened():
        print("無法啟動攝影機，請檢查設備。")
        return

    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    if face_cascade.empty():
        print("無法加載人臉檢測模型。")
        return

    count = 0
    print("開始捕捉臉部圖像，按下 'q' 鍵退出。")

    while True:
        ret, frame = cam.read()
        if not ret:
            print("無法讀取影像。")
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.05, minNeighbors=3, minSize=(30, 30))

        for (x, y, w, h) in faces:
            face_img = frame[y:y+h, x:x+w]
            save_path = os.path.join(save_dir, f"{user_id}_{count}.jpg")
            cv2.imwrite(save_path, face_img)  # 保存人臉圖像
            count += 1
            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)

        cv2.imshow("Face Capture", frame)  # 顯示視窗
        if cv2.waitKey(1) & 0xFF == ord('q') or count >= 100:
            break

    cam.release()
    cv2.destroyAllWindows()
    print(f"已保存 {count} 張臉部圖像，使用者 ID: {user_id}")

capture_user_face("yourname")
